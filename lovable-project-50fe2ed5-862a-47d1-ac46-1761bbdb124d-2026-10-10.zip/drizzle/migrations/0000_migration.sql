create type public.app_role as enum ('admin','user');
create table public.user_roles (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users(id) on delete cascade not null, role app_role not null, unique(user_id, role));
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create or replace function public.has_role(_user_id uuid, _role app_role) returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.user_roles where user_id=_user_id and role=_role) $$;
create policy "own roles" on public.user_roles for select to authenticated using (user_id = auth.uid());

-- first signup becomes admin
create or replace function public.first_user_admin() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if not exists (select 1 from public.user_roles where role='admin') then
    insert into public.user_roles(user_id, role) values (new.id,'admin');
  end if;
  return new;
end $$;
create trigger on_auth_user_created_admin after insert on auth.users for each row execute function public.first_user_admin();

create table public.products (
  id uuid primary key default gen_random_uuid(),
  category text not null default 'premium',
  tag text not null default 'HIBURAN',
  name text not null,
  badge text,
  description text,
  duration text,
  price integer not null,
  sort integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
grant select on public.products to anon, authenticated;
grant insert, update, delete on public.products to authenticated;
grant all on public.products to service_role;
alter table public.products enable row level security;
create policy "public read active" on public.products for select using (active or public.has_role(auth.uid(),'admin'));
create policy "admin write" on public.products for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

insert into public.products (category, tag, name, badge, description, duration, price, sort) values
('premium','HIBURAN','Netflix Premium Private','Private','Akses privat untuk satu pengguna.','1 bulan',35000,1),
('premium','HIBURAN','Netflix Premium Sharing','Sharing','Satu akun, berbagi akses.','1 bulan',25000,2),
('premium','MUSIK','Spotify Premium','Teman harian','Musik untuk setiap suasana.','1 bulan',25000,3),
('premium','KREATIVITAS','CapCut Premium','Untuk kreator','Buat setiap ide jadi karya.','1 bulan',42000,4),
('premium','HIBURAN','YouTube Premium','Premium','Lebih banyak tontonan. Lebih nyaman.','1 bulan',25000,5),
('premium','MUSIK','Apple Music 3 bulan','3 bulan','Musik tanpa iklan, tiga bulan.','3 bulan',32000,6),
('iphone','LAYANAN','Unblock IMEI 1 bulan',null,'Pemeriksaan kelayakan jaringan','1 bulan',135000,7),
('iphone','LAYANAN','Unblock IMEI 3 bulan slow',null,'Jalur reguler • pemulihan jaringan','3 bulan',185000,8),
('iphone','LAYANAN','Unblock IMEI 3 bulan fast',null,'Jalur prioritas • pemulihan jaringan','3 bulan',235000,9),
('iphone','LAYANAN','Bypass iPhone 6 – 17 Pro Max',null,'Pemeriksaan akses • iPhone 6 – 17 Pro Max','-',250000,10);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  whatsapp text not null,
  items jsonb not null,
  subtotal integer not null,
  unique_code integer not null,
  total integer not null,
  payment_method text not null,
  status text not null default 'menunggu',
  created_at timestamptz not null default now()
);
grant select, update, delete on public.orders to authenticated;
grant all on public.orders to service_role;
alter table public.orders enable row level security;
create policy "admin all orders" on public.orders for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create or replace function public.create_order(_name text, _wa text, _items jsonb, _method text) returns public.orders language plpgsql security definer set search_path=public as $$
declare sub integer := 0; it jsonb; p record; code integer; r public.orders; clean jsonb := '[]'::jsonb;
begin
  if length(trim(_name)) < 1 or length(_name) > 100 or length(_wa) < 8 or length(_wa) > 20 then raise exception 'Data tidak valid'; end if;
  if _method not in ('QRIS','DANA','SEABANK') then raise exception 'Metode tidak valid'; end if;
  for it in select * from jsonb_array_elements(_items) loop
    select * into p from public.products where id = (it->>'id')::uuid and active;
    if not found then raise exception 'Produk tidak ditemukan'; end if;
    sub := sub + p.price * greatest(1, least(20, (it->>'qty')::int));
    clean := clean || jsonb_build_object('id',p.id,'name',p.name,'price',p.price,'qty',greatest(1, least(20, (it->>'qty')::int)));
  end loop;
  if sub = 0 then raise exception 'Keranjang kosong'; end if;
  code := 1 + floor(random()*9)::int;
  insert into public.orders(customer_name, whatsapp, items, subtotal, unique_code, total, payment_method)
  values (trim(_name), trim(_wa), clean, sub, code, sub+code, _method) returning * into r;
  return r;
end $$;
create or replace function public.get_order(_id uuid) returns public.orders language sql stable security definer set search_path=public as $$ select * from public.orders where id=_id $$;
grant execute on function public.create_order(text,text,jsonb,text) to anon, authenticated;
grant execute on function public.get_order(uuid) to anon, authenticated;

create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  buyer_name text not null,
  last_message_at timestamptz not null default now(),
  unread_admin integer not null default 0,
  created_at timestamptz not null default now()
);
create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender text not null,
  body text not null,
  created_at timestamptz not null default now()
);
grant select, update, delete on public.conversations to authenticated;
grant select, insert, delete on public.messages to authenticated;
grant all on public.conversations to service_role;
grant all on public.messages to service_role;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
create policy "admin convs" on public.conversations for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "admin msgs" on public.messages for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create or replace function public.start_conversation(_name text) returns uuid language plpgsql security definer set search_path=public as $$
declare cid uuid;
begin
  if length(trim(_name)) < 1 or length(_name) > 60 then raise exception 'Nama tidak valid'; end if;
  insert into public.conversations(buyer_name) values (trim(_name)) returning id into cid;
  return cid;
end $$;
create or replace function public.buyer_send(_cid uuid, _body text) returns void language plpgsql security definer set search_path=public as $$
begin
  if length(trim(_body)) < 1 or length(_body) > 1000 then raise exception 'Pesan tidak valid'; end if;
  if not exists (select 1 from public.conversations where id=_cid) then raise exception 'Percakapan tidak ada'; end if;
  insert into public.messages(conversation_id, sender, body) values (_cid,'buyer',trim(_body));
  update public.conversations set last_message_at=now(), unread_admin=unread_admin+1 where id=_cid;
end $$;
create or replace function public.buyer_messages(_cid uuid) returns setof public.messages language sql stable security definer set search_path=public as $$ select * from public.messages where conversation_id=_cid order by created_at $$;
grant execute on function public.start_conversation(text) to anon, authenticated;
grant execute on function public.buyer_send(uuid,text) to anon, authenticated;
grant execute on function public.buyer_messages(uuid) to anon, authenticated;

alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.conversations;
alter publication supabase_realtime add table public.orders;